## Pluralsight Guide: Testing React Components with TypeScript

To run the sample:

    npm install

    # To start
    npm start

    # To test
    npm test
    npm test:watch