import React, { useContext } from 'react';
import { MyContext } from './MyContext';

function MainComp(props) {
    const mycont= useContext(MyContext)
    return (
        <div>
            {mycont.map((user)=>(
                <div>{user.name} ---{user.email}</div>
            ))}
        </div>
    );
}

export default MainComp;