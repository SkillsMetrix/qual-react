import React from 'react';
import MainComp from './MainComp';

function MyComponent(props) {
    return (
        <div>
            <MainComp/>
        </div>
    );
}

export default MyComponent;