import React, { useState } from 'react';
import logo from './logo.svg';
import './App.css';
import MainApp from './components/MainApp';
import UserApp from './components/UserApp';
import { MyContext } from './contextapp/MyContext';
import MyComponent from './contextapp/MyComponent';
import Register from './components/Register';
import RestApp from './components/RestApp';
const userData=[{name:'admin',email:'admin@mail.com'}]
function App() {
  const [user,setUser]= useState(userData)
  return (
    <div className="App">
   <RestApp/>
    </div>
  );
}

export default App;
