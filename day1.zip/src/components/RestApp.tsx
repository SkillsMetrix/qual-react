import React, { useEffect, useState } from 'react';
import { fetchData } from './SampleService';
function RestApp(props) {
    const [users,setUsers]=useState([])
const loadUsers = () => {
        const data = fetchData().then((data) => {
           setUsers(data)

        })
    }
    useEffect(() => {
        loadUsers()
    }, [])
    return (
        <div>
{users}
        </div>
    );
}

export default RestApp;