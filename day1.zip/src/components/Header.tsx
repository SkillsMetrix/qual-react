 import React from 'react';

function Header(props) {
    return (
        <div>
             <button disabled={!props.hasData}>Delete All</button>
        </div>
    );
}
export default Header; 
