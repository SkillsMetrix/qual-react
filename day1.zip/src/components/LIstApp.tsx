

import React, { FC } from 'react';
/* 
function LIstApp(props) {
    return (
        <div>
            {props.udata.map((data)=> (
                <div>{data}</div>
            ))}
        </div>
    );
}

export default LIstApp; */

const LIstApp :FC<{data:string[]}>=({data}) => (

    <ul>
        {data.map(item => <li>{item}</li>)}
    </ul>
)
export default LIstApp