import Footer from "./Footer";
import Header from "./Header";
import LIstApp from "./LIstApp";

function MainApp() {
  const headerData='welcome to header'
  const userData=['admin','manager','QA']
  return (
    <div>
      <Header hdata={headerData}/>
      <p>MainApp</p>
      <Footer firstName="admin" email="admin@mail.com"/>
      <LIstApp data={userData}/>
    </div>
  );
}
export default MainApp;
