import React from 'react';
import User from './User';

function Users(props) {

    return (
        <div>
            {
                props.data.map((user) => (<User ud={user} du={props.du} />))
            }
        </div>
    )
}

export default Users;