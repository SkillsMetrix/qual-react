import React from 'react';

function User(props) {
    return (
        <div>
            {props.ud.uname}
            <button onClick={()=> props.du(props.ud.uname)}>Delete</button>
        </div>
    );
}

export default User;