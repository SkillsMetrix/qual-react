


import React, { useState } from 'react';

function AddUser(props) {
    const [uname, setUname] = useState('')
    const [email, setUEmail] = useState('')

    const addUser = (e) => {
        e.preventDefault()
        props.addus(uname, email)
    }
    return (
        <div>
            <form onSubmit={addUser}>
                UserName:<input type='text' value={uname} onChange={(e) => setUname(e.target.value)} />
                Email:<input type='text' value={email} onChange={(e) => setUEmail(e.target.value)} />
                <button>Add User</button>
            </form>
        </div>
    );
}

export default AddUser;