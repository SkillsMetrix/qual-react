import axios from "axios";

const URL = 'https://jsonplaceholder.typicode.com/users'
const fetchData = (): Promise<any> => {
    return axios.get(URL)
        .then((response) => response.data)
}
export {fetchData}