
import { log } from 'console';
import React, { useEffect, useState } from 'react';
import AddUser from './AddUser';
import Users from './Users';
import Header from './Header';


function UserApp() {

    const [users, setUsers] = useState([])

    const deleteUser = (usr) => {
        setUsers(users.filter((user) => user.uname !== usr))
    }
    const addUserToArray = (uname, email) => {

        setUsers([...users, { uname, email }])

    }

    return (
        <div>
            <Header hasData={users.length > 0} />
            <AddUser addus={addUserToArray} />
            <hr />
            <Users du={deleteUser} data={users} />


        </div>
    );
}

export default UserApp;