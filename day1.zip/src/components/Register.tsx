


import React, { useState } from 'react';

function Register(props) {
    const [formData, setFormData] = useState({})

    const handleData = (e) => {
        setFormData({
            ...formData, [e.target.name]: e.target.value

        })
    }
 const addUser = (e) => {
        e.preventDefault()
        const data = JSON.stringify(formData)
        localStorage.setItem('qual', data)

    }
    return (
        <div>
            <form onSubmit={addUser}>
                UserName:<input type='text' name='uname' onChange={handleData} />
                Email:<input type='text' name='email' onChange={handleData} />
                <button>Add User</button>
            </form>
        </div>
    );
}

export default Register;