

 interface UserData {
    firstName: string
    email:string
    city?:string
 }
function Footer({firstName,email,city='Hyderabad'}:UserData) {
    
    return (
        <div>

            {firstName} --{email} --{city}
        </div>
    );
}

export default Footer;