export default interface IPage {
    name: string;
}