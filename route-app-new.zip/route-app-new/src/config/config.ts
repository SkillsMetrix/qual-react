const config = {
    defaults: {
        namespace: 'Application'
    }
}

export default config;