import React from "react";

function AddProduct() {
  return (
    <div className="listOfProducts">
      <h1> Add Product</h1>
    </div>
  );
}

export default AddProduct;
